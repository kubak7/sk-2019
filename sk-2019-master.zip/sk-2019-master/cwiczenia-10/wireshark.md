analiza ruchu sieciowego
------------------------

  * https://www.tcpdump.org/
  * https://www.wireshark.org/
  * https://wiki.wireshark.org/CaptureFilters

Zadanie
------------

![zadanie 10](arch.svg)

1.
   * Przygotuj konfigurację sieci zgodnie z powyższym diagramem
   * Uruchom PC2 w z wykorzystaniem dystrybucji z interfejsem graficznym
   * Zainstaluj program wireshark dla ``PC2``
   * Wykonaj analizę i zanotuj spostrzerzenia
     * tcp echo server vs udp echo server
     * tcp http wysyłka wiadomosci do ``http-chat``   
   
      
